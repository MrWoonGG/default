1.- Upload the public folder to /var/www/pterodactyl

2.- Open /var/www/pterodactyl/resources/views/templates/wrapper.blade.php under of "@include('layouts.scripts')" 
 VIEW IMAGE.PNG Copy the code that your arc.io account gives you 

3.- Use yarn build:production

THANKS!!